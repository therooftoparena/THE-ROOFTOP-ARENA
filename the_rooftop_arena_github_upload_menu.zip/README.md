# THE ROOFTOP ARENA Menu Website

GitHub Pages ready website for THE ROOFTOP ARENA.

## Files
- `index.html` — main restaurant menu website

## How to upload on GitHub Pages
1. Create a new public repository on GitHub.
2. Upload `index.html`.
3. Go to Settings → Pages.
4. Source: Deploy from branch.
5. Branch: main.
6. Folder: /root.
7. Save and open your live GitHub Pages link.

Restaurant:
THE ROOFTOP ARENA
Bhojubeer Panchkoshi Road, Varanasi
Contact: 6386889752 | 6393568798
Instagram: @rooftoparena.vns
